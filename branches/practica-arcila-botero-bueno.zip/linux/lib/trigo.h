/* @(#)trigo.h
 */

#ifndef _TRIGO_H
#define _TRIGO_H 1

extern float seno();
extern float coseno();
extern float tangente();

#endif /* _TRIGO_H */

