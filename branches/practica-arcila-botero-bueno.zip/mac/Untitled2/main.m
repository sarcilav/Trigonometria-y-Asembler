//
//  main.m
//  Untitled2
//
//  Created by Sergio on 8/19/09.
//  Copyright sergiobuj@gmail.com 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
